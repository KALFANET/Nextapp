
import React from 'react';

const Dashboard = () => {
    return (
        <div>
            <h1>Welcome to the Dashboard</h1>
            <p>Here you can manage your sales and packages.</p>
        </div>
    );
};

export default Dashboard;
